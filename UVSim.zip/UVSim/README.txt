##  Instructions only for Prototype Build  ##

Use the terminal to input commands. The first three characters will be '+XX', where XX is a code for an operation.
i.e. '+11' is WRITE. The next two characters will be a memory address '+XXxx', where xx is the memory address.

EX: Write value in memory location '00' into console: '+1100'

Working commands:

READ    / '+10XX': Read the following console input into memory location 'XX'.
WRITE   / '+11XX': Write value at memory location 'XX' into console.
LOAD    / '+20XX': 
STORE   / '+21XX': 

Hit enter to close the program